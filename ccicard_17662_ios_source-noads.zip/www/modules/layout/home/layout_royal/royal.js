function myFunction() {
   var element = document.getElementById("myDIV");
   element.classList.toggle("royal_on");
}