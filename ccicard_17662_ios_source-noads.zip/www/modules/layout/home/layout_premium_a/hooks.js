/**
 *
 * Layout_PremiumA example
 *
 * All the following functions are required in order for the Layout to work
 */
App.service('layout_premium_a', function ($rootScope, HomepageLayout) {

    var service = {};

    /**
     * Must return a valid template
     *
     * @returns {string}
     */
    service.getTemplate = function() {
        return "modules/layout/home/layout_premium_a/view.html";
    };

    /**
     * Must return a valid template
     *
     * @returns {string}
     */
    service.getModalTemplate = function() {
        return "templates/home/l10/modal.html";
    };

    /**
     * onResize is used for css/js callbacks when orientation change
     */
    service.onResize = function() {
        /** Do nothing for this particular one */
    };

    /**
     * Manipulate the features objects
     *
     * Examples:
     * - you can re-order features
     * - you can push/place the "more_button"
     *
     * @param features
     * @param more_button
     * @returns {*}
     */
    service.features = function(features, more_button) {
        /** Place more button at the end */
        //features.overview.options.push(more_button);
		//localStorage.setItem("agc240templateMenu", JSON.stringify(features));
        return features;
    };
	
    return service;

});

App.controller('agc240templatecontroller', function($scope,Url,$ionicSideMenuDelegate,$rootScope, $timeout, $translate, $location, $compile, $sce, $window, Application, Customer,   Dialog,  HomepageLayout, $log, $http)
{
	$scope.is_loading = true;
	$scope.is_logged_in = Customer.isLoggedIn();
	$scope.avatar_url = null;
	$scope.options = {};

	$scope.options.slide1_richtext="";
	$scope.options.slide2_richtext="";
	$scope.options.slide3_richtext="";
	$scope.options.slide4_richtext="";
	$scope.options.slide5_richtext="";
	$scope.options.slide6_richtext="";
	$scope.options.slide7_richtext="";
	$scope.options.slide8_richtext="";
	$scope.options.slide9_richtext="";
	$scope.options.slide10_richtext="";
	
	$scope.options.slide1_image="";
	$scope.options.slide2_image="";
	$scope.options.slide3_image="";
	$scope.options.slide4_image="";
	$scope.options.slide5_image="";
	$scope.options.slide6_image="";
	$scope.options.slide7_image="";
	$scope.options.slide8_image="";
	$scope.options.slide9_image="";
	$scope.options.slide10_image="";
	
	$scope.fix_style = "";
	
	$scope.wallet_score = 0;
	$scope.wallet_option = {};
	$scope.mcommerce_option = {};
	$scope.mobilcart_option = {};
	$scope.restaraunt_option = {};
	$scope.wallet = {};
	$scope.mcommerce = {};
	$scope.mobilcart = {};
	$scope.restaraunt = {};
	$scope.wallet_found = false;
	$scope.mcommerce_found = false;
	$scope.mobilcart_found = false;
	$scope.restaraunt_found = false;
	$scope.features2 = {};
	
	$scope.customer = {};	
	console.log("scope.is_logged_in:");
	console.log($scope.is_logged_in);
	var upperJS = document.createElement("script"); // visual effet on touch
	upperJS.type = "text/javascript";
	upperJS.src = "modules/layout/home/layout_premium_a/upmobile.js";
	upperJS.onload = function() {
	HomepageLayout.getFeatures().then(function(features) {
		console.log(features);
		$scope.options = features.layoutOptions;
		$scope.features2 = features.options;
		//make full pathname
		//modules/layout/home/layout_premium_a/images/icons/white/

		//assign images
		var domain = Url.get("/");
		var domain_splitted = domain.split("/");
		$scope.protocol = domain_splitted[0];
		$scope.domian_url = domain_splitted[2];
		$scope.is_open_menu = false;
		$scope.pointer_events = "none";
		
		if ($scope.options.slide1_img!="") $scope.options.slide1_image=$scope.protocol + "//"+$scope.domian_url +"/images/application"+$scope.options.slide1_img;
		if ($scope.options.slide2_img!="") $scope.options.slide2_image=$scope.protocol + "//"+$scope.domian_url +"/images/application"+$scope.options.slide2_img;
		if ($scope.options.slide3_img!="") $scope.options.slide3_image=$scope.protocol + "//"+$scope.domian_url +"/images/application"+$scope.options.slide3_img;
		if ($scope.options.slide4_img!="") $scope.options.slide4_image=$scope.protocol + "//"+$scope.domian_url +"/images/application"+$scope.options.slide4_img;
		if ($scope.options.slide5_img!="") $scope.options.slide5_image=$scope.protocol + "//"+$scope.domian_url +"/images/application"+$scope.options.slide5_img;
		if ($scope.options.slide6_img!="") $scope.options.slide6_image=$scope.protocol + "//"+$scope.domian_url +"/images/application"+$scope.options.slide6_img;
		if ($scope.options.slide7_img!="") $scope.options.slide7_image=$scope.protocol + "//"+$scope.domian_url +"/images/application"+$scope.options.slide7_img;
		if ($scope.options.slide8_img!="") $scope.options.slide8_image=$scope.protocol + "//"+$scope.domian_url +"/images/application"+$scope.options.slide8_img;
		if ($scope.options.slide9_img!="") $scope.options.slide9_image=$scope.protocol + "//"+$scope.domian_url +"/images/application"+$scope.options.slide9_img;
		if ($scope.options.slide10_img!="") $scope.options.slide10_image=$scope.protocol + "//"+$scope.domian_url +"/images/application"+$scope.options.slide10_img;
		
		//Remove slides 2 and 3, if needed
		if ($scope.options.slide2_enable!='1') document.getElementById("swiper-slide-2").remove();
		if ($scope.options.slide3_enable!='1') document.getElementById("swiper-slide-3").remove();
		if ($scope.options.slide4_enable!='1') document.getElementById("swiper-slide-4").remove();
		if ($scope.options.slide5_enable!='1') document.getElementById("swiper-slide-5").remove();
		if ($scope.options.slide6_enable!='1') document.getElementById("swiper-slide-6").remove();
		if ($scope.options.slide7_enable!='1') document.getElementById("swiper-slide-7").remove();
		if ($scope.options.slide8_enable!='1') document.getElementById("swiper-slide-8").remove();
		if ($scope.options.slide9_enable!='1') document.getElementById("swiper-slide-9").remove();
		if ($scope.options.slide10_enable!='1') document.getElementById("swiper-slide-10").remove();
		
		if ($scope.options.slide1_rich!="") $scope.options.slide1_richtext=$scope.mb64toutf($scope.options.slide1_rich);
		if ($scope.options.slide2_rich!="") $scope.options.slide2_richtext=$scope.mb64toutf($scope.options.slide2_rich);
		if ($scope.options.slide3_rich!="") $scope.options.slide3_richtext=$scope.mb64toutf($scope.options.slide3_rich);
		if ($scope.options.slide4_rich!="") $scope.options.slide4_richtext=$scope.mb64toutf($scope.options.slide4_rich);
		if ($scope.options.slide5_rich!="") $scope.options.slide5_richtext=$scope.mb64toutf($scope.options.slide5_rich);
		if ($scope.options.slide6_rich!="") $scope.options.slide6_richtext=$scope.mb64toutf($scope.options.slide6_rich);
		if ($scope.options.slide7_rich!="") $scope.options.slide7_richtext=$scope.mb64toutf($scope.options.slide7_rich);
		if ($scope.options.slide8_rich!="") $scope.options.slide8_richtext=$scope.mb64toutf($scope.options.slide8_rich);
		if ($scope.options.slide9_rich!="") $scope.options.slide9_richtext=$scope.mb64toutf($scope.options.slide9_rich);
		if ($scope.options.slide10_rich!="") $scope.options.slide10_richtext=$scope.mb64toutf($scope.options.slide10_rich);
		
		var swiper_options = {
			pagination: {
				el: '.swiper-pagination',
				clickable: true,
			},
			//loop: true,
		 };

		//if ($scope.options.bullet_type=="dynamic") swiper_options.pagination.dynamicBullets = true;
		if ($scope.options.slider_auto_play==1) swiper_options.autoplay = {delay: 2500,disableOnInteraction: false};
		if ($scope.options.slider_touch_slide!=1) swiper_options.simulateTouch = false;
		if ($scope.options.slider_free_mode=="yes") swiper_options.freeMode = true;
		if ($scope.options.slider_effect=="fade") swiper_options.effect = 'fade';
		if ($scope.options.slider_effect=="flip") swiper_options.effect = 'flip';
		if ($scope.options.slider_effect=="cube") swiper_options.effect = 'cube';

		$scope.loadContent();
		var swiper = new Swiper('.swiper-container', swiper_options);
		
		//Прочитаем из памяти значения
		if ($window.localStorage.getItem("agc240templatecontroller_wallet_score")!="") $scope.wallet_score = $window.localStorage.getItem("agc240templatecontroller_wallet_score");
		if ($window.localStorage.getItem("agc240templatecontroller_wallet_found")=="yes") $scope.wallet_found = true;


   
   
		//Включим опции и значки
		features.options.forEach(function(element) {
			
			//Кошелек
			if ( ($scope.options.show_wallet_badge=="yes" || $scope.options.show_wallet_icon=="yes") && element.code=="wallet" && $scope.is_logged_in) {
				$scope.wallet_option = element;
				//$scope.wallet =  $pwaRequest.get("wallet/mobile_view/find", { urlParams: { value_id: element.id }, cache: false, refresh: true });
				
				$http({method: 'GET', url: Url.get("wallet/mobile_view/find",{value_id:element.id}),cache: false,responseType:'json'}).success(function(data) {
					$scope.wallet = data;
					console.log("Wallet found in maket:");
					console.log($scope.wallet);
					$scope.wallet_score = data.customer.score;
					$window.localStorage.setItem("agc240templatecontroller_wallet_score",$scope.wallet_score);
					$scope.wallet_found = true;
					$window.localStorage.setItem("agc240templatecontroller_wallet_found","yes");
				}).error(function (error) {
  					console.log("Wallet found error:");
					console.log(error); 
					$window.localStorage.setItem("agc240templatecontroller_wallet_found","no");
            
                });

			}
			
			
			//mcommerce
			if ($scope.options.show_mcommerce_badge=="yes" && element.code=="m_commerce" && $scope.is_logged_in) {
				$scope.mcommerce_option = element;
				//$scope.wallet =  $pwaRequest.get("wallet/mobile_view/find", { urlParams: { value_id: element.id }, cache: false, refresh: true });
				
				$http({method: 'GET', url: Url.get("mcommerce/mobile_cart/find",{value_id:element.id}),cache: false,responseType:'json'}).success(function(data) {
					$scope.mcommerce = data;
					console.log("mcommerce found in maket:");
					console.log($scope.mcommerce);
					$scope.mcommerce_found = true;					
				}).error(function (error) {
  					console.log("mcommerce found error:");
					console.log(error);                  
            
                });
			}
			
			//mobilcart
			if ($scope.options.show_mobilcart_badge=="yes" && element.code=="m_mobilcart" && $scope.is_logged_in) {
				$scope.mobilcart_option = element;
				$http({method: 'GET', url: Url.get("mmobilcart/mobile_cart/find",{value_id:element.id}),cache: false,responseType:'json'}).success(function(data) {
					$scope.mobilcart = data;
					console.log("mobilcart found in maket:");
					console.log($scope.mobilcart);
					$scope.mobilcart_found = true;					
				}).error(function (error) {
  					console.log("mobilcart found error:");
					console.log(error);                  
            
                });
			}



			//restaurants
			if ($scope.options.show_restaraunt_badge=="yes" && element.code=="restaurants" && $scope.is_logged_in) {
				$scope.restaraunt_option = element;
				$http({method: 'GET', url: Url.get("restaurants/mobile_cart/getbadgeqty",{value_id:element.id}),cache: false,responseType:'json'}).success(function(data) {
					$scope.restaraunt = data;
					console.log("restaraunt found in maket:");
					console.log($scope.restaraunt);
					$scope.restaraunt_found = true;					
				}).error(function (error) {
  					console.log("restaraunt found error:");
					console.log(error);                  
            
                });
			}
			
			
			
		});	   
   
		
	});	
	
	};
	document.body.appendChild(upperJS);

	$scope.mb64toutf = function(str64) {
		console.log(str64);
		return decodeURIComponent(atob(str64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
		}).join(''));
	};

	//Беджи в левом меню
	$scope.showBadge = function(element) {
	
		//иначе вернем 0 
		if (element.code == 'wallet' && $scope.options.show_wallet_badge=="yes" && $scope.wallet_found  && $scope.is_logged_in) return $scope.wallet.bills_pending
		else if (element.code == 'm_commerce' && $scope.options.show_mcommerce_badge=="yes" && $scope.mcommerce_found  && $scope.is_logged_in) {
			var cart_total = 0;
			$scope.mcommerce.cart.lines.forEach(function(line) {
				cart_total = cart_total + line.qty;
			})
			return cart_total;
		} 
		else if (element.code == 'm_mobilcart' && $scope.options.show_mobilcart_badge=="yes" && $scope.mobilcart_found  && $scope.is_logged_in) {
			var cart_total = 0;
			$scope.mobilcart.cart.lines.forEach(function(line) {
				cart_total = cart_total + line.qty;
			})
			return cart_total;
		}
		else if (element.code == 'restaurants' && $scope.options.show_restaraunt_badge=="yes" && $scope.restaraunt_found  && $scope.is_logged_in) {
			return $scope.restaraunt.qty;
		}		
		else return 0;

	}
	
	//Беджи на главной
	$scope.showMainBadge = function(element) {
	
		//иначе вернем 0 
		if (element.code == 'wallet' && $scope.options.show_wallet_badge=="yes" && $scope.wallet_found  && $scope.is_logged_in) return $scope.wallet.bills_pending
		else if (element.code == 'm_commerce' && $scope.options.show_mcommerce_badge=="yes" && $scope.mcommerce_found  && $scope.is_logged_in) {
			var cart_total = 0;
			$scope.mcommerce.cart.lines.forEach(function(line) {
				cart_total = cart_total + line.qty;
			})
			return cart_total;
		} 
		else if (element.code == 'm_mobilcart' && $scope.options.show_mobilcart_badge=="yes" && $scope.mobilcart_found  && $scope.is_logged_in) {
			var cart_total = 0;
			$scope.mobilcart.cart.lines.forEach(function(line) {
				cart_total = cart_total + line.qty;
			})
			return cart_total;
		}
		else if (element.code == 'restaurants' && $scope.options.show_restaraunt_badge=="yes" && $scope.restaraunt_found  && $scope.is_logged_in) {
			return $scope.restaraunt.qty;
		}		
		else return 0;

	}	
	
	
	$scope.loadContent = function() {

		if ($scope.is_logged_in) {
			Customer.find().then(function(customer) {
				$scope.customer = customer;
				$scope.customer.metadatas = _.isObject($scope.customer.metadatas) ? $scope.customer.metadatas : {};
				$scope.avatar_url = Customer.getAvatarUrl($scope.customer.id);
			return customer;		
			})
			.then(function() {
				/*
				wmprty
				*/
			})
			.then(function() {
				$scope.is_logged_in = true;
				$scope.is_loading = false;		
			});
		} else {
			$scope.is_logged_in = false;
			$scope.is_loading = false;	
		}		
		
	};
	
	$scope.goToFeature = function(f) {
		console.log("Click feature:");
		console.log(f);
	}

	$scope.openPanel = function(event) {
			//document.getElementById("panel-overlay").style.display = "block";
		console.log("$scope.openPanel event run");
		if(!$ionicSideMenuDelegate.isOpenLeft())
		{
			console.log("$scope.openPanel event do");
			$ionicSideMenuDelegate.toggleLeft();
			$scope.fix_style = "transform: translate3d(275px, 0px, 0px) !important;";
			console.log($scope.fix_style);
			//document.getElementById("panel-overlay").style.display = "block";
			//enable mouse event
			//.menu-open .menu-content .pane, .menu-open .menu-content .scroll-content {pointer-events: none !important;}
			$scope.pointer_events = "none";
			$timeout( function(){
				$scope.is_open_menu = true;			
				$scope.pointer_events = "auto";
				var ratio = $ionicSideMenuDelegate.getOpenRatio();
				console.log(ratio);
			}, 400 );				
			
		}
	}
	$scope.closePanel = function() {
		console.log("$scope.closePanel event run");
			console.log("$scope.closePanel event do");
			$scope.fix_style = "transform: translate3d(0px, 0px, 0px) !important;";
			$scope.is_open_menu = false;
			$ionicSideMenuDelegate.toggleLeft();
			
		if($ionicSideMenuDelegate.isOpenLeft())
		{
			console.log("$scope.closePanel event do");
			$scope.fix_style = "transform: translate3d(0px, 0px, 0px) !important;";
			$scope.is_open_menu = false;
			$ionicSideMenuDelegate.toggleLeft();
			$scope.pointer_events = "none";
			$timeout( function(){
				$scope.pointer_events = "none";
			}, 300 );	
		
		}
	}

	
  $scope.clickOnlogout = function() {
	Dialog.confirm($translate.instant("Confirmation"), $translate.instant("Are you sure?"), ["Yes", "No"])
    .then(function (result) {
        if (result) {
			$scope.is_loading = true;
			Customer.logout()
			.then(function(data) {
				$scope.is_loading = false;
				if (data.success) {
					$scope.is_logged_in = false;
				}
			})
			.then(function() {
				$scope.is_loading = false;
				$scope.display_login_form = true;
				$scope.display_account_form = false;
				$scope.display_forgot_password_form = false;
			});
        } else {
            // Cancelled
        }
    });
	
  };	
  
  $scope.clickLogin = function() {
	Customer.loginModal();
	/*Customer.loginModal($scope, function() {
		$scope.has_avatar = true;
		$scope.is_logged_in = true;
		console.log("login modal first func");
		$scope.updateScopeOnAuthEvent();
	}, function() {
		$scope.is_logged_in = false; 
		console.log("login modal second func");
		$scope.updateScopeOnAuthEvent();
	});*/
  };
  
  $scope.openFeature = function(feature_id) {
  
	console.log("openFeature clicked:");
	if (feature_id!="") {
		if(typeof $scope.features.overview.options[feature_id] === 'undefined') {
			// does not exist
			
		}
		else {
			// does exist
			HomepageLayout.openFeature($scope.features.overview.options[feature_id], $scope);
		}	
	
	}

  };
  
  $scope.updateScopeOnAuthEvent = function() {
    $scope.is_loading = true;
	console.log("$scope.updateScopeOnAuthEvent:");
	console.log(Customer.isLoggedIn());
	if (Customer.isLoggedIn()) {
		Customer.find().then(function(customer) {
			console.log("$scope.updateScopeOnAuthEvent found customer:");
			console.log(customer);
			$scope.customer = customer;
			$scope.avatar_url = Customer.getAvatarUrl($scope.customer.id);
			console.log("$scope.updateScopeOnAuthEvent avatar_url:"+$scope.avatar_url);
			$scope.is_logged_in = true;
		})
		.then(function() {
			$scope.is_loading = false;
			$scope.is_logged_in = true;
		});		
	} else {
		$scope.customer = {};
		$scope.is_logged_in = false;
		$scope.is_loading = false;
	}
	
    /*Customer.find()
      .then(function(customer) {
          if (Customer.isLoggedIn()) {
            $scope.is_logged_in = true;
			$scope.has_avatar = true;			
			$scope.avatar_url = Customer.getAvatarUrl($scope.customer.id);
			$scope.has_avatar = true;			
			
          } else {
            $scope.is_logged_in = false;
          }
        if (customer.length === 0) {
          customer = { email: "", password: "" };
        }
        $scope.customer = customer;
        $scope.customer.metadatas = _.isObject($scope.customer.metadatas)? $scope.customer.metadatas: {};

		console.log("$scope.updateScopeOnAuthEvent:");
		console.log($scope.customer);
        return customer;
      })
      .then(function() {
        $scope.is_loading = false;
      });
	  */
  }
	$scope.trustAsHtml = function(string) {
		return $sce.trustAsHtml(string);
	};
	
  $rootScope.$on("auth-login-success", function() {
    $log.debug("auth-login-success");
    $scope.updateScopeOnAuthEvent();
  });

  $rootScope.$on("auth-logout-success", function() {
    $log.debug("auth-logout-success");
     $scope.updateScopeOnAuthEvent();
  });

  $rootScope.$on("auth-register-success", function() {
    $log.debug("auth-register-success");
     $scope.updateScopeOnAuthEvent();
  });
  
	$scope.openFeature = function(feature) {
		console.log("openFeature clicked:");
		console.log(feature);
		HomepageLayout.openFeature(feature, $scope);

	};
	
	$scope.openMainPageFeature = function(value_id) {
		console.log("openMainPageFeature clicked:");
		console.log(value_id);
		$scope.features2.forEach(function(element) {
			if (element.value_id==value_id) {
				HomepageLayout.openFeature(element, $scope);
			}
		});
	}	
}); 