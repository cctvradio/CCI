cordova.define("Geofence.TransitionType", function(require, exports, module) {
var TransitionType = {
    ENTER: 1,
    EXIT: 2,
    BOTH: 3,
};

module.exports = TransitionType;

});
